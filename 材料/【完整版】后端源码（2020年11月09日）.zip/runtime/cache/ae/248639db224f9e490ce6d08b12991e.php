<?php
//000000000000
 exit();?>
think_serialize:a:7:{s:8:"username";s:11:"15827301112";s:5:"phone";s:11:"15827301112";s:11:"create_time";i:1562139266;s:11:"update_time";i:1562139266;s:2:"id";s:2:"59";s:9:"logintype";s:5:"phone";s:5:"token";s:40:"8677d512c53e58d0e33c59b789312a7313ed14cf";}