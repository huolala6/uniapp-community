<?php
//000000000000
 exit();?>
think_serialize:a:10:{s:2:"id";i:13;s:8:"username";s:9:"昵111称";s:7:"userpic";s:77:"https://douyinzcmcss.oss-cn-shenzhen.aliyuncs.com/shengchengqi/userpic1/3.jpg";s:8:"password";s:60:"$2y$10$qxkOOPPBKc1eY4m40InHWe.7gzeW.wfIIj5e8KmAfJ0svCWH45Zqu";s:5:"phone";s:11:"13450772008";s:5:"email";s:10:"111@qq.com";s:6:"status";i:1;s:11:"create_time";i:1556790013;s:9:"logintype";s:8:"username";s:5:"token";s:40:"d56ad69cf8a433d3076e5f3938e870f26e952eac";}