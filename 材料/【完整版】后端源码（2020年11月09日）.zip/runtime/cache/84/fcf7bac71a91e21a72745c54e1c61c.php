<?php
//000000000000
 exit();?>
think_serialize:a:10:{s:2:"id";i:41;s:8:"username";s:11:"15523831999";s:7:"userpic";N;s:8:"password";s:0:"";s:5:"phone";s:11:"15523831999";s:5:"email";N;s:6:"status";i:1;s:11:"create_time";i:1561370626;s:9:"logintype";s:5:"phone";s:5:"token";s:40:"fcfb44f7f2a932dd269903e2b6716fa4f1ba6faf";}