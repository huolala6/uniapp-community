<?php
//000007776000
 exit();?>
think_serialize:a:9:{s:4:"type";s:2:"qq";s:6:"openid";s:32:"C7AC650F5BF2CE95DBB7FC508F45FCB2";s:8:"nickname";s:6:"红香";s:9:"avatarurl";s:74:"http://qzapp.qlogo.cn/qzapp/1104455702/C7AC650F5BF2CE95DBB7FC508F45FCB2/30";s:2:"id";s:2:"31";s:7:"user_id";i:0;s:10:"expires_in";s:7:"7776000";s:9:"logintype";s:2:"qq";s:5:"token";s:40:"8ac7a6d0fa052afbb993b16a6789e5b65eb096c1";}