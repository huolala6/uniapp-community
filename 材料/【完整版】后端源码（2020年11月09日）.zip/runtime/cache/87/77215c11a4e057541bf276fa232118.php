<?php
//000000000000
 exit();?>
think_serialize:a:8:{s:8:"username";s:11:"13653628961";s:5:"phone";s:11:"13653628961";s:11:"create_time";i:1562148916;s:11:"update_time";i:1562148916;s:2:"id";s:2:"62";s:9:"logintype";s:5:"phone";s:5:"token";s:40:"16ed7bcac44674fdfda2388149eededa9d36e7ea";s:5:"email";s:11:"4123@qq.com";}