<?php
//000000000000
 exit();?>
think_serialize:a:10:{s:2:"id";i:7;s:8:"username";s:6:"zcmcss";s:7:"userpic";s:77:"https://douyinzcmcss.oss-cn-shenzhen.aliyuncs.com/shengchengqi/userpic1/1.jpg";s:8:"password";s:0:"";s:5:"phone";s:11:"13450772004";s:5:"email";s:10:"123@qq.com";s:6:"status";i:1;s:11:"create_time";N;s:9:"logintype";s:5:"phone";s:5:"token";s:40:"7318259b03e928ad4386834ac636518d5f996b9f";}