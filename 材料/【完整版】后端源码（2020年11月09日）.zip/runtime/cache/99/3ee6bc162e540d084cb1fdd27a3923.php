<?php
//000007776000
 exit();?>
think_serialize:a:9:{s:2:"id";i:38;s:4:"type";s:2:"qq";s:6:"openid";s:32:"806381229EA37B8DA552BAAF89DC0169";s:7:"user_id";i:55;s:8:"nickname";s:12:"一撇一捺";s:9:"avatarurl";s:74:"http://qzapp.qlogo.cn/qzapp/1104455702/806381229EA37B8DA552BAAF89DC0169/30";s:9:"logintype";s:2:"qq";s:10:"expires_in";s:7:"7776000";s:5:"token";s:40:"342207f18a983cf5580f3b2727d89388b63609f6";}