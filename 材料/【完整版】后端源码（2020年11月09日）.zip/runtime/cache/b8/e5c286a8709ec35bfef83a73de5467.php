<?php
//000000000000
 exit();?>
think_serialize:a:1:{i:0;a:7:{s:5:"to_id";s:2:"14";s:7:"from_id";i:65;s:13:"from_username";s:11:"13546121236";s:12:"from_userpic";s:77:"https://krplus-pic.b0.upaiyun.com/avatar/201812/28095646/fde0v5pcswzft2s8!120";s:4:"type";s:4:"text";s:4:"data";s:3:"f3w";s:4:"time";i:1562308431;}}