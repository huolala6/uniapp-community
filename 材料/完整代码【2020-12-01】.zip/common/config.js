export default {
	// api请求前缀
	// #ifdef H5
	webUrl:'/api',
	// #endif
	// #ifndef H5
	webUrl:'https://ceshi2.dishait.cn/api/v1',
	// #endif
	// websocket地址
	websocketUrl:"wss://ceshi2.dishait.cn/wss",
}